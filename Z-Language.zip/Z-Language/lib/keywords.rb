 def keywords
    [
      'text', 'img', 'form', 'newline',
      'url', 'size', 'bold', 'italic',
      'input', 'select', 'submit',
      'times'
    ]
 end
 
 def keywords_space
	[
      '=',
      'def', 'end'
    ]
 end
